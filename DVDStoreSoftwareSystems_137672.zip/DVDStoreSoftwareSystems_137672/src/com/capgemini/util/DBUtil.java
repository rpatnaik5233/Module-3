package com.capgemini.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {

	public static Connection getConnection() throws SQLException, ClassNotFoundException, IOException {
		Connection connection = null;
		try {
			InitialContext context = new InitialContext();
			DataSource dataSource;
			dataSource = (DataSource) context.lookup("java:/OracleDS");
			connection = dataSource.getConnection();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		}
		return connection;

	}
}
