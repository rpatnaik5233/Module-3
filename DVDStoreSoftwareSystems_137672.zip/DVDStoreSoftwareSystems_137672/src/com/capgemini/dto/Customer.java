package com.capgemini.dto;

import java.time.LocalDate;

public class Customer {
	private String name;
	private int dvdId;
	private LocalDate dvdIssueDate;
	private LocalDate dvdReturnDate;
	private double deposit;

	public Customer() {
		super();
	}

	public Customer(String name, int dvdId, LocalDate dvdIssueDate, LocalDate dvdReturnDate, double deposit) {
		super();
		this.name = name;
		this.dvdId = dvdId;
		this.dvdIssueDate = dvdIssueDate;
		this.dvdReturnDate = dvdReturnDate;
		this.deposit = deposit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDvdId() {
		return dvdId;
	}

	public void setDvdId(int dvdId) {
		this.dvdId = dvdId;
	}

	public LocalDate getDvdIssueDate() {
		return dvdIssueDate;
	}

	public void setDvdIssueDate(LocalDate dvdIssueDate) {
		this.dvdIssueDate = dvdIssueDate;
	}

	public LocalDate getDvdReturnDate() {
		return dvdReturnDate;
	}

	public void setDvdReturnDate(LocalDate dvdReturnDate) {
		this.dvdReturnDate = dvdReturnDate;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
}
