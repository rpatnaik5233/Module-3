package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dto.Customer;
import com.capgemini.dto.DVD;
import com.capgemini.service.DVDServiceImpl;
import com.capgemini.service.IDVDService;

@WebServlet("/DVDController")
public class DVDController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	//Association between Controller And Service
	private IDVDService dvdService;

	public DVDController() 
	{
		dvdService = new DVDServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doProcess(request, response);
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		HttpSession session = request.getSession( true );
		RequestDispatcher rd=null;
		
		if (action != null) 
		{
	//==================================Start ShowHomePage=====================================//
			try {
				if (action.equalsIgnoreCase("ShowHomePage")) 
				{
					rd = request.getRequestDispatcher("Pages/Home.jsp");
					rd.forward(request, response);
				}
	//==================================End ShowHomePage=====================================//
	
	//==================================Start Login==========================================//			
				if (action.equalsIgnoreCase("Login")) 
				{
					String userName = request.getParameter("UserName");
					
					session.setAttribute("userName", userName);
					rd = request.getRequestDispatcher("Pages/Customer.jsp");
					rd.forward(request, response);
				}
	//==================================End Login==============================================//			
				
	//==================================Start ShowIssueDVD=====================================//		
				if (action.equalsIgnoreCase("ShowIssueDVD")) 
				{
					try 
					{
						ArrayList<DVD> dvdList = dvdService.getAllDVD();
						request.setAttribute("dvdList", dvdList);
						rd = request.getRequestDispatcher("Pages/ShowIssueDVD.jsp");
						rd.forward(request, response);
					} 
					catch (Exception e) 
					{
						rd = request.getRequestDispatcher("Pages/DVDError.jsp");
						rd.forward(request, response);
					}
				}
	//==================================End ShowIssueDVD=====================================//					
	
	//==================================Start IssueDVD=======================================//
				if (action.equalsIgnoreCase("IssueDVD")) 
				{
					int dvdId = Integer.parseInt(request.getParameter("dvdId"));
				
					String userName = (String) session.getAttribute("userName");
					double depositAmount = 200;
					LocalDate issueDate = LocalDate.now();
					LocalDate returnDate = LocalDate.now().plusDays(2);
					Customer customer = new Customer(userName, dvdId, issueDate, returnDate, depositAmount);
					try 
					{
						dvdService.addCustomerDetails(customer);
						request.setAttribute("customer", customer);
						rd = request.getRequestDispatcher("Pages/CalculateDVDRent.jsp");
						rd.forward(request, response);
					}
					catch (Exception e) 
					{
						rd = request.getRequestDispatcher("Pages/DVDError.jsp");
						rd.forward(request, response);
					}
				}
	//==================================End IssueDVD==========================================//		
				
			} 
			catch (Exception e) 
			{
				rd = request.getRequestDispatcher("Pages/DVDError.jsp");
				rd.forward(request, response);
			}
		}
		else 
		{
			PrintWriter printWriter = response.getWriter();
			printWriter.println("No action Defined.");
		}
	}

}
