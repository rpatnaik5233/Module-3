package com.cg.pmc.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.pmc.bean.FirmMaster;
import com.cg.pmc.service.IRegisterService;
import com.cg.pmc.service.RegisterServiceImpl;


@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig config = null;
	IRegisterService registerService=null;
    public RegisterController() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		this.config = config;
	}

	
	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		RequestDispatcher rd = null;
		registerService=new RegisterServiceImpl();
		HttpSession session = request.getSession(true);
		if(action!=null)
		{
			try 
			{
				
				if (action.equalsIgnoreCase("ShowHomePage")) {
					rd = request.getRequestDispatcher("Home.jsp");
					rd.forward(request, response);
				}
				
				if (action.equalsIgnoreCase("ShowRegisterPage")) {
					rd = request.getRequestDispatcher("register.jsp");
					rd.forward(request, response);
				}
				
				if(action.equalsIgnoreCase("InsertFirm"))
				{
					String authname=request.getParameter("Fname");
					String bname=request.getParameter("BName");
					String email=request.getParameter("Eid");
					String mobno=request.getParameter("Mno");
					FirmMaster firm=new FirmMaster(authname,bname,email,mobno);
					int firmAdded=registerService.registerFirm(firm);
					if(firmAdded!=0)
					{
						session.setAttribute("email", email);
						session.setAttribute("Activationcode",Math.ceil(Math.random()*1000000)+10000);
						rd = request.getRequestDispatcher("registered.jsp");
						rd.forward(request, response);
					}
					
				}
				
				if(action.equalsIgnoreCase("ShowActivatePage"))
				{
					rd = request.getRequestDispatcher("Activate.jsp");
					rd.forward(request, response);
				}
						
				if(action.equalsIgnoreCase("checkActivationPage"))
				{
					String eid=request.getParameter("email");
					String acode=request.getParameter("Acode");		
					
				}
				
				if(action.equalsIgnoreCase("showActivationPage"))
				{
					rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
				}
			}
			
			catch (Exception e) 
			{
				PrintWriter pw=response.getWriter();
				pw.print("No action defined");
			}
		}
		else
		{
			String errorMsg="Invalid Deatils provided";
			request.setAttribute("MsgObj",errorMsg);
		}
	}

}
