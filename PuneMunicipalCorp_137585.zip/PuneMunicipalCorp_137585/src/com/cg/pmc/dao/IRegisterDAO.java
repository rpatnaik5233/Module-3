package com.cg.pmc.dao;

import com.cg.pmc.bean.FirmMaster;
import com.cg.pmc.exception.FirmException;

public interface IRegisterDAO {

	public int registerFirm(FirmMaster f) throws FirmException;
}
