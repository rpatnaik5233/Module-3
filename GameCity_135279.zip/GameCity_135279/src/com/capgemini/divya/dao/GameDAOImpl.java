package com.capgemini.divya.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.divya.dto.GameBean;
import com.capgemini.divya.dto.UserBean;
import com.capgemini.divya.exception.GameException;
import com.capgemini.divya.util.DBUtil;

/**
 *  Author : Divya Sharma
 *  Class Name : GameDAOImpl
 *  Package :com.capgemini.divya.dao; 
 *  Date : Sept 25, 2017
 */
/*
 * DAO class for database interaction
 */
public class GameDAOImpl implements IGameDAO {
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;
	
	public int generateUserId() throws GameException {
		
		
		int id = 0;
		Connection connection = DBUtil.obtainConnection();

		try {

			Statement stm = connection.createStatement();

			ResultSet res = stm.executeQuery("select seq_users.nextval from dual");

			if (res.next() == false) {
				throw new GameException("Failed in generating User Id");
			}

			id = res.getInt(1);

			
			
		} catch (Exception e) {

			throw new GameException(e);
		}

		return id;

	}
	
	@Override
	public void buyCard(UserBean user) throws GameException {
		// TODO Auto-generated method stub
		int userId = 0;
		Connection connection = DBUtil.obtainConnection();
		
		String insertSql = "INSERT INTO users VALUES(?,?,?,?)";
		
		try {
			userId = generateUserId();
						System.out.println(userId);
			preparedStatement = connection.prepareStatement(insertSql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, user.getUserName());
			preparedStatement.setString(3, user.getAddress());
			preparedStatement.setInt(4, user.getCardAmt());

			preparedStatement.executeUpdate();

			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new GameException("Error while database interaction:::"
					+ e.getMessage());
		}	
		
	}
	
	@Override
	public List<GameBean> getGameDetails() throws GameException 
	{
		List<GameBean> listGames = new ArrayList<>();
		Connection connection = DBUtil.obtainConnection();
		PreparedStatement preparedStatement = null;

		try {
			preparedStatement = connection
					.prepareStatement("SELECT * FROM ONLINEGAMES");
			 rsSet = preparedStatement.executeQuery();

			int index = 0;
			while (rsSet.next()) {
				listGames.add(new GameBean(rsSet.getString("name"),rsSet.getInt("amount")));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listGames;
		
		
	}
	
}
