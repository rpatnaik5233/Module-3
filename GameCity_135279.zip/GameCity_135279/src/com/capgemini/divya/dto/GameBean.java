package com.capgemini.divya.dto;

public class GameBean {
	private String name;
	private int amount;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "GameBean [name=" + name + ", amount=" + amount + "]";
	}

	public GameBean(String name, int amount) {
		super();
		this.name = name;
		this.amount = amount;
	}

	public GameBean() {
		super();
		// TODO Auto-generated constructor stub
	}

}
