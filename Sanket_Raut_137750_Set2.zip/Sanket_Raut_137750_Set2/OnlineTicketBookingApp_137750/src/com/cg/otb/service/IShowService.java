package com.cg.otb.service;

import java.util.List;

import com.cg.otb.dto.ShowDetails;
import com.cg.otb.exception.ShowException;

public interface IShowService 
{
	List<ShowDetails> getShowDetails() throws ShowException ;
	public ShowDetails getShowDetail(String showid) throws ShowException ;
	public void updateShowDetails(int seats , String showname) throws ShowException ;
}
