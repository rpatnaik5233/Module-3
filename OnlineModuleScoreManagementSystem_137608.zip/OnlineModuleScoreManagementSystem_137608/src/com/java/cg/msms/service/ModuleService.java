package com.java.cg.msms.service;

import java.util.ArrayList;

import com.java.cg.msms.dto.TraineeBean;
import com.java.cg.msms.exception.TraineeException;



public interface ModuleService {


	public int addDetails(TraineeBean bean) throws TraineeException;
	
	public TraineeBean viewDetails(int id) throws TraineeException;
	
	public ArrayList<Integer> getId() throws TraineeException;
}
