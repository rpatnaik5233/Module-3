package com.java.cg.msms.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	public static Connection getConnection() throws SQLException, ClassNotFoundException, IOException {
		// Connection con = null;
		// Properties prop = loadDBProperties();
		// Class.forName(prop.getProperty("driver"));
		// con = DriverManager.getConnection(prop.getProperty("url"),
		// prop.getProperty("username"),
		// prop.getProperty("password"));
		// return con;

		Connection connection = null;
		try {
			InitialContext context = new InitialContext();
			DataSource dataSource;
			dataSource = (DataSource) context.lookup("java:/OracleDS");
			connection = dataSource.getConnection();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		}
		return connection;

	}

	public static Properties loadDBProperties() throws IOException {
		String path = "Database.properties";
		InputStream propsFile = null;
		Properties dbProperties = new Properties();
		propsFile = new FileInputStream(path);
		dbProperties.load(propsFile);
		propsFile.close();
		return dbProperties;
	}

}
