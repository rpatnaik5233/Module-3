package com.java.cg.msms.dto;

public class TraineeBean {

	int id;
	String module_name;
	int mpt_no;
	int mtt_no;
	int ass_marks;
	int total_no;
	int grade;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public int getMpt_no() {
		return mpt_no;
	}
	public void setMpt_no(int mpt_no) {
		this.mpt_no = mpt_no;
	}
	public int getMtt_no() {
		return mtt_no;
	}
	public void setMtt_no(int mtt_no) {
		this.mtt_no = mtt_no;
	}
	public int getAss_marks() {
		return ass_marks;
	}
	public void setAss_marks(int ass_marks) {
		this.ass_marks = ass_marks;
	}
	public int getTotal_no() {
		return total_no;
	}
	public void setTotal_no(int total_no) {
		this.total_no = total_no;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public TraineeBean(String module_name, int mpt_no, int mtt_no, int ass_marks, int total_no, int grade) {
		super();
		this.module_name = module_name;
		this.mpt_no = mpt_no;
		this.mtt_no = mtt_no;
		this.ass_marks = ass_marks;
		this.total_no = total_no;
		this.grade = grade;
	}
	public TraineeBean(int id, String module_name, int mpt_no, int mtt_no, int ass_marks, int total_no, int grade) {
		super();
		this.id = id;
		this.module_name = module_name;
		this.mpt_no = mpt_no;
		this.mtt_no = mtt_no;
		this.ass_marks = ass_marks;
		this.total_no = total_no;
		this.grade = grade;
	}
	
	
	
}
