package com.cg.mra.ui;

import java.util.Scanner;
import org.apache.log4j.PropertyConfigurator;
import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.service.IAccountService;
import com.cg.mra.util.ValidationUtil;



//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Application User Interface
	 */

	
//=================================================================================================================


//==============================================INTERFACE MENU===================================

interface MainMenu{
	
	public static int ACCOUNT_BAL_ENQ = 1;
	public static int RECHARGE_ACCOUNT = 2;
	public static int EXIT = 3;
}

//============================================MAIN USER INTERFACE=================================

public class AccountUI implements MainMenu{
	
	Scanner scanner = new Scanner(System.in);
	
	IAccountService accountService;

	public AccountUI() {
		
		accountService = new AccountServiceImpl();
	}
	
	
	public void menu(){
		
		System.out.println("============MENU============");
		System.out.println("Enter Your Choice : ");
		System.out.println("1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. Exit Application");
		
		int choice = scanner.nextInt();
		
		switch (choice) {
		case ACCOUNT_BAL_ENQ: accountBalanceEnquiry(); break;
		case RECHARGE_ACCOUNT:	rechargeAccount(); break;
		case EXIT: 
			System.out.println("GOOD BYE");
			System.exit(0);
			
			break;

		default:
			System.out.println("Wrong Choice. Select Again");
			break;
		}

}

//==========================================RECHARGE ACCOUNT METHOD=============================
	
	private void rechargeAccount() {
		
		System.out.println("======RECHARGE ACCOUNT======");
		
		Scanner console = new Scanner(System.in);
		String accountID=null;
		double rechargeAmount=0.0;
		do{
			System.out.println("Enter ACCOUNT ID: ");
			accountID=console.next();
		}while(ValidationUtil.isAccountIdInvalid(accountID));
			
		do{
			System.out.println("Enter Recharge Amount: ");
			rechargeAmount=console.nextDouble();
		}while(ValidationUtil.isAccountBalanceInvalid(rechargeAmount));
		try{
			int accountRecharge = accountService.rechargeAccount(accountID, rechargeAmount);
			System.out.println("Your Account Recharged Successfully");
		}
		catch(Exception e){
			System.out.println("Something wrong while retriving the data, Reason "+e.getMessage());
		}
		
	}

//=================================================BALANCE ENQUIRY METHOD=====================================
	
	private void accountBalanceEnquiry() {
		
		System.out.println("===================ACCOUNT BALANCE ENQUIRY=========================");
		String accountId;
		do
		{
		System.out.println("Enter Account Id: ");
		accountId = scanner.next();
		}while(ValidationUtil.isAccountIdInvalid(accountId));

		
		//Fetch Record From database via service
		
		try 
		{
			Account account = accountService.getAccountDetails(accountId);
			
			System.out.println("Your Current Balance is Rs. " + account.getAccountBalance());

			
		} catch (AccountException e) {
			
			System.out.println("Something went wrong while trying to fetch information. Reason: " + e.getMessage());
		}
		
	}
	
	
//===================================================MAIN METHOD==========================================================
	
	public static void main(String atrgs[])
	{
		
		PropertyConfigurator.configure("log4j.properties");
		
		AccountUI ui = new AccountUI();
			
		while(true)
		{
			ui.menu();
		}
	}
}
