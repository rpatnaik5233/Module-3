package com.capgemini.web.csrm.service;

import java.util.List;

import com.capgemini.web.csrm.dao.CricketScoreDAO;
import com.capgemini.web.csrm.dao.ICricketScoreDAO;
import com.capgemini.web.csrm.dto.PlayerBean;
import com.capgemini.web.csrm.exception.CricketScoreException;

/**
 * @author srohilla
 *
 */
public class CricketServiceImpl implements ICricketService {
	
	ICricketScoreDAO cricketScoreDAO;
	
	/**
	 * 
	 */
	public CricketServiceImpl() {
		cricketScoreDAO=new CricketScoreDAO();
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.web.csrm.service.ICricketService#addPlayer(com.capgemini.web.csrm.dto.PlayerBean)
	 */
	@Override
	public int addPlayer(PlayerBean playerBean) throws CricketScoreException {
		return cricketScoreDAO.addPlayer(playerBean);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.web.csrm.service.ICricketService#viewAllPlayers()
	 */
	@Override
	public List<PlayerBean> viewAllPlayers() throws CricketScoreException {
		return cricketScoreDAO.viewAllPlayers();
	}


}
