package com.capgemini.web.csrm.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.web.csrm.dto.PlayerBean;
import com.capgemini.web.csrm.exception.CricketScoreException;
import com.capgemini.web.csrm.util.DBUtil;

/**
 * @author srohilla
 *
 */
public class CricketScoreDAO implements ICricketScoreDAO {

	/* (non-Javadoc)
	 * @see com.capgemini.web.csrm.dao.ICricketScoreDAO#addPlayer(com.capgemini.web.csrm.dto.PlayerBean)
	 */
	
	/***************************************************************
	 * Inserting The Player Details in Cricket_Score Table
	 * @param PlayerBean
	 * @return int
	 * @throws CricketScoreException
	 ***************************************************************/
	@Override
	public int addPlayer(PlayerBean playerBean) throws CricketScoreException {
		int playerId=0;
		try(Connection con=DBUtil.getConnection()){
			Statement stm=con.createStatement();
			
			ResultSet res=stm.executeQuery("select player_seq.nextval from dual");
			if(res.next()==false){
				throw new Exception("Player id could not be generated");
			}
			playerBean.setPlayerId(res.getInt(1));
			
			PreparedStatement pstm=con.prepareStatement("insert into cricket_score values(?,?,?,?,?,?,?,?)");
			pstm.setInt(1, playerBean.getPlayerId());
			pstm.setString(2, playerBean.getPlayerName());
			pstm.setDate(3, Date.valueOf(playerBean.getDateOfBirth()));
			pstm.setString(4, playerBean.getCountry());
			pstm.setString(5, playerBean.getBattingStyle());
			pstm.setInt(6, playerBean.getCenturies());
			pstm.setInt(7, playerBean.getMatches());
			pstm.setInt(8, playerBean.getTotalRunScore());
			pstm.execute();
			playerId=playerBean.getPlayerId();
		}catch (Exception e) {
			throw new CricketScoreException(e.getMessage());
		}
		
		return playerId;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.web.csrm.dao.ICricketScoreDAO#viewAllPlayers()
	 */
	/***************************************************************
	 * Fetching all the Players Details from Cricket_Score Table
	 * @param 
	 * @return List<PlayerBean>
	 * @throws CricketScoreException
	 ***************************************************************/
	@Override
	public List<PlayerBean> viewAllPlayers() throws CricketScoreException {
		List<PlayerBean> playerBeans=null;
		
		try(Connection con=DBUtil.getConnection()){
			Statement stm=con.createStatement();
			
			ResultSet res=stm.executeQuery("select * from cricket_score");
			if(res.next()==false){
				throw new Exception("No Entry for Cricket Players");
			}
			playerBeans = new ArrayList<PlayerBean>();
			do{
				PlayerBean playerBean=new PlayerBean();
				playerBean.setPlayerId(res.getInt(1));
				playerBean.setPlayerName(res.getString(2));
				playerBean.setDateOfBirth(res.getDate(3).toLocalDate());
				playerBean.setCountry(res.getString(4));
				playerBean.setBattingStyle(res.getString(5));
				playerBean.setCenturies(res.getInt(6));
				playerBean.setMatches(res.getInt(7));
				playerBean.setTotalRunScore(res.getInt(8));
				playerBeans.add(playerBean);
			}while(res.next());
			
		}catch (Exception e) {
			throw new CricketScoreException(e.getMessage());
		}
		return playerBeans;
	}


}
