package com.cg.modulescoremanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cg.modulescoremanagement.dto.AssesmentScore;
import com.cg.modulescoremanagement.dto.Trainees;
import com.cg.modulescoremanagement.exception.ModuleException;

public class ModuleManagementDao implements IModuleManagement
{

	public ModuleManagementDao() 
	{
		
	}

	@Override
	public ArrayList<Trainees> getTrainee() throws ModuleException 
	{
		/*
		 * Author:Gurpreet
		 * Emp ID: 137442
		 * Date: 07th nov 2017
		 * Description: getting list of trainees
		 */
		ArrayList<Trainees> trainees = null;
		try (Connection con = com.cg.modulescoremanagement.utill.DBUtil.getConnection()) {
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from trainees");
			trainees = new ArrayList<>();

			while (res.next()) {
				Trainees empTemp = new Trainees();

				empTemp.setId(res.getInt(1));
				empTemp.setName(res.getString(2));
				

				trainees.add(empTemp);
			}
			if (trainees.isEmpty()) {
				throw new Exception("No Details to Display");
			}

		} catch (Exception e) {
			
			throw new ModuleException(e.getMessage());
		}
		
		return trainees;
	}

	@Override
	public AssesmentScore addScore(AssesmentScore obj) throws ModuleException 
	{
		/*
		 * Author:Gurpreet
		 * Emp ID: 137442
		 * Date: 07th nov 2017
		 * Description: adding data to table 
		 */
		int id = 0;

		try (Connection con = com.cg.modulescoremanagement.utill.DBUtil.getConnection()) {

			PreparedStatement pstm = con
					.prepareStatement("insert into assessmentscore values(?,?,?,?,?,?,?)");

			

			pstm.setInt(1, obj.getId());
			pstm.setString(2, obj.getModuleName());
			pstm.setInt(3, obj.getMpt());
			pstm.setInt(4, obj.getMtt());
			pstm.setInt(5, obj.getAss_marks());
			pstm.setInt(6, obj.getTotal());
			pstm.setInt(7, obj.getGrade());

			pstm.execute();

			id = obj.getId();
			
			

		} catch (Exception e) {
			// e.printStackTrace();
			new ModuleException(e.getMessage());
		}
		return obj;
		
	}

}
