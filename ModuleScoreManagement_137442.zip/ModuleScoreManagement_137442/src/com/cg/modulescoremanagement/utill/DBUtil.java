package com.cg.modulescoremanagement.utill;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil 
{
	public static Connection getConnection() throws NamingException, SQLException
	{
		Connection con=null;
		try
		{
		InitialContext context=new InitialContext();
		DataSource source=(DataSource)context.lookup("java:/OracleDS");
		con=source.getConnection();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}