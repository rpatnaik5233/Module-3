package com.cg.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.exception.EbillException;
import com.cg.ebill.service.ConsumerService;
import com.cg.ebill.service.ConsumerServiceImpl;
import com.cg.ebill.service.EbillService;
import com.cg.ebill.service.EbillServiceImpl;
import com.sun.mail.iap.Response;

@SuppressWarnings("serial")
@WebServlet("*.mvc")
public class EbillController extends HttpServlet {
	EbillService obj=new EbillServiceImpl();
	
	ConsumerService obj1=new ConsumerServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String path=request.getServletPath();
		PrintWriter out=response.getWriter();
		float lastReading;
		switch(path){
		case "/DisplayConsumer.mvc":
			try{
				List<Consumer> list=obj.fetchConsumerDetails();
				HttpSession session=request.getSession();
				session.setAttribute("consumerList", list);
				response.sendRedirect("ConsumerList.jsp");
			}catch(EbillException | IOException e){
				request.getSession().setAttribute("errorMsg", "Error retreiving "+"data from db "+e.getMessage());
				response.sendRedirect("Error.jsp");
			}
			break;
		case"/SearchConsumer.mvc":
			int ID=Integer.parseInt(request.getParameter("consumerNum"));
			try {
				HttpSession session1=request.getSession();
				List<Consumer> list = obj.searchConsumer(ID);
			session1.setAttribute("consumerDetails", list);
			response.sendRedirect("ShowConsumer.jsp");
			} catch (EbillException e) {
				request.getSession().setAttribute("errorMsg", "Error occured in retreiving "+"data from db "+e.getMessage());
				response.sendRedirect("Error.jsp");
			}
			break;
		case"/SearchConsumerForm.mvc":
			response.sendRedirect("SearchConsumer.jsp");
			break;
		case"/Home.mvc":
			response.sendRedirect("index.html");
		case"/CalculateBill.mvc":
			int consumerNum=Integer.parseInt(request.getParameter("consumerNum"));
			lastReading=Float.parseFloat(request.getParameter("lastReading"));
			request.getSession().setAttribute("consumerNum", consumerNum);
			request.getSession().setAttribute("lastReading", lastReading);
			response.sendRedirect("UserInfo.jsp");
			break;
		case"/CalculateBillMain.mvc":
			int custNum=Integer.parseInt(request.getParameter("consumerNum"));
			lastReading=Float.parseFloat(request.getParameter("lastReading"));
			float currentReading=Float.parseFloat(request.getParameter("currentReading"));
			float units=currentReading-lastReading;
			Bill bills=new Bill();
			bills.setConsumerNum(custNum);
			bills.setCurrentReading(currentReading);
			bills.setUnitConsumed(units);
			bills.setBillDate(LocalDate.now());
			bills.setNetAmount(units);
			try {
				obj1.insertBill(bills);
				request.getSession().setAttribute("consumerNum", custNum);
				List<Consumer> list = obj.searchConsumer(custNum);
				request.getSession().setAttribute("consumerDetails", list);
				float unit=bills.getUnitConsumed();
				float amount=bills.getNetAmount();
				request.getSession().setAttribute("unitConsumed", unit);;
				request.getSession().setAttribute("netAmt", amount);
				response.sendRedirect("BillInfo.jsp");
				
			} catch (EbillException e1) {
				request.getSession().setAttribute("errorMsg", "Error occured in inserting bill in database "+e1.getMessage());
				response.sendRedirect("Error.jsp");
			}
			break;
		case"/ShowDetails.mvc":
			int consumerNum1=Integer.parseInt(request.getParameter("consumerNum"));
			request.getSession().setAttribute("consumerNum", consumerNum1);
			try{
				List<Bill> billList=obj1.searchBill(consumerNum1);
				if(billList==null || billList.isEmpty()){
					request.getSession().setAttribute("errorMsg", "No Bill Details for Consumer Number: "+consumerNum1);
					response.sendRedirect("ErrorBill.jsp");
				}
				else{
					request.getSession().setAttribute("billList", billList);
					response.sendRedirect("ShowBills.jsp");
					
				}
			}catch(EbillException e){
				request.getSession().setAttribute("errorMsg", "Error occured in retreiving "+"data from db "+e.getMessage());
				response.sendRedirect("Error.jsp");
			}
			break;
		default:
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
