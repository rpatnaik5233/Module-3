package com.cg.ebill.service;

import java.util.List;
import com.cg.ebill.dao.EbillDAO;
import com.cg.ebill.dao.EbillDAOImpl;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.exception.EbillException;

public class EbillServiceImpl implements EbillService {
	EbillDAO dao=new EbillDAOImpl();
	@Override
	public List<Consumer> fetchConsumerDetails() throws EbillException{
		return dao.getConsumerList();
	}
	@Override
	public List<Consumer> searchConsumer(int ID) throws EbillException{
		return dao.searchConsumer(ID);
	}
}
